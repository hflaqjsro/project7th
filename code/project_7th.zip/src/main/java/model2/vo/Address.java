package model2.vo;

public class Address {
	/*
	 CREATE TABLE address(
	addressNum varchar2(8) PRIMARY key, -- add-0001
	memNum varchar2(8),
	defaultAddress varchar2(100),
	detailAddress varchar2(100)
);
	 
	 */
	
	private String memNum;
	private String addressNum;
	private String defaultAddress;
	private String detailAddress;
	public Address() {
		super();
	}
	
	
	public Address(String memNum) {
		super();
		this.memNum = memNum;
	}


	public Address(String memNum, String addressNum, String defaultAddress, String detailAddress) {
		super();
		this.memNum = memNum;
		this.addressNum = addressNum;
		this.defaultAddress = defaultAddress;
		this.detailAddress = detailAddress;
	}
	public String getMemNum() {
		return memNum;
	}
	public void setMemNum(String memNum) {
		this.memNum = memNum;
	}
	public String getAddressNum() {
		return addressNum;
	}
	public void setAddressNum(String addressNum) {
		this.addressNum = addressNum;
	}
	public String getDefaultAddress() {
		return defaultAddress;
	}
	public void setDefaultAddress(String defaultAddress) {
		this.defaultAddress = defaultAddress;
	}
	public String getDetailAddress() {
		return detailAddress;
	}
	public void setDetailAddress(String detailAddress) {
		this.detailAddress = detailAddress;
	}
	
}
