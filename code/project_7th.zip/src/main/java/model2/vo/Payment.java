package model2.vo;

public class Payment {
	/*
	 CREATE TABLE payment(
	payNum varchar2(8) PRIMARY key, -- pay-0001
	memNum varchar2(8),
	bankName varchar2(20),
	cardNum varchar2(19) --  -포함 19자
		); 
	  
	 */
	
	private String memNum;
	private String payNum;
	private String bankName;
	private String cardNum;
	public Payment() {
		super();
	}
	
	
	public Payment(String memNum) {
		super();
		this.memNum = memNum;
	}


	public Payment(String memNum, String payNum, String bankName, String cardNum) {
		super();
		this.memNum = memNum;
		this.payNum = payNum;
		this.bankName = bankName;
		this.cardNum = cardNum;
	}


	public String getMemNum() {
		return memNum;
	}


	public void setMemNum(String memNum) {
		this.memNum = memNum;
	}


	public String getPayNum() {
		return payNum;
	}


	public void setPayNum(String payNum) {
		this.payNum = payNum;
	}


	public String getBankName() {
		return bankName;
	}


	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	public String getCardNum() {
		return cardNum;
	}


	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}
	
	
}
