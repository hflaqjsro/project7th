package teamP_07;

public class Admin {
	private String eeeNum;
	private String id;
	private String pass;
	private String name;
	private String tel;
	private String email;
	private String income;
	private int auth;
	private String auth_name;
	private String pos_name;
	private String sysdate;
	
	
	public Admin() {
		super();
	}

	public Admin(String eeeNum) {
		super();
		this.eeeNum = eeeNum;
	}
	

	public String getSysdate() {
		return sysdate;
	}

	public void setSysdate(String sysdate) {
		this.sysdate = sysdate;
	}

	public String getEeeNum() {
		return eeeNum;
	}


	public String getId() {
		return id;
	}


	public String getPass() {
		return pass;
	}


	public String getName() {
		return name;
	}


	public String getTel() {
		return tel;
	}


	public String getEmail() {
		return email;
	}


	public String getIncome() {
		return income;
	}


	public int getAuth() {
		return auth;
	}


	public String getAuth_name() {
		return auth_name;
	}


	public String getPos_name() {
		return pos_name;
	}


	public void setEeeNum(String eeeNum) {
		this.eeeNum = eeeNum;
	}


	public void setId(String id) {
		this.id = id;
	}


	public void setPass(String pass) {
		this.pass = pass;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void setTel(String tel) {
		this.tel = tel;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public void setIncome(String income) {
		this.income = income;
	}


	public void setAuth(int auth) {
		this.auth = auth;
	}


	public void setAuth_name(String auth_name) {
		this.auth_name = auth_name;
	}


	public void setPos_name(String pos_name) {
		this.pos_name = pos_name;
	}
	
	

	
}
