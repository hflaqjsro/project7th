package teamP_07;

public class Member {
	private String memNum;
	private String mID;
	private String mName;
	private int report;
	private String memgrade;
	private String joinDate;
	private String modDate;
	private String memImg;
	private String memText;
	private String memPhone;
	
	private String pfNum;
	private String pfTitle;
	private String pfStateNum;
	
	
	
	public Member() {
		super();
	}
	public Member(String id) {
		super();
		this.mID = id;
	}
	public Member(String memNum, String mID, String mName, int report, String memgrade, String joinDate) {
		super();
		this.memNum = memNum;
		this.mID = mID;
		this.mName = mName;
		this.report = report;
		this.memgrade = memgrade;
		this.joinDate = joinDate;
	}
	public Member(String memNum, String mID, String memgrade, String pfnum, String pftitle, String pfStateNum) {
		super();
		this.memNum = memNum;
		this.mID = mID;
		this.memgrade = memgrade;
		this.pfNum = pfnum;
		this.pfTitle = pftitle;
		this.pfStateNum = pfStateNum;
	}
	public String getMemNum() {
		return memNum;
	}
	public String getmID() {
		return mID;
	}
	public String getmName() {
		return mName;
	}
	public int getReport() {
		return report;
	}
	public String getMemgrade() {
		return memgrade;
	}
	public String getJoinDate() {
		return joinDate;
	}
	public String getModDate() {
		return modDate;
	}
	public String getpfNum() {
		return pfNum;
	}
	public String getpfTitle() {
		return pfTitle;
	}
	
	public String getMemImg() {
		return memImg;
	}
	public String getMemText() {
		return memText;
	}
	public String getMemPhone() {
		return memPhone;
	}
	public String getPfNum() {
		return pfNum;
	}
	public String getPfTitle() {
		return pfTitle;
	}
	public String getPfStateNum() {
		return pfStateNum;
	}
	public void setMemImg(String memImg) {
		this.memImg = memImg;
	}
	public void setMemText(String memText) {
		this.memText = memText;
	}
	public void setMemPhone(String memPhone) {
		this.memPhone = memPhone;
	}
	public void setPfNum(String pfNum) {
		this.pfNum = pfNum;
	}
	public void setPfTitle(String pfTitle) {
		this.pfTitle = pfTitle;
	}
	public void setPfStateNum(String pfStateNum) {
		this.pfStateNum = pfStateNum;
	}
	public void setMemNum(String memNum) {
		this.memNum = memNum;
	}
	public void setmID(String mID) {
		this.mID = mID;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public void setReport(int report) {
		this.report = report;
	}
	public void setMemgrade(String memgrade) {
		this.memgrade = memgrade;
	}
	public void setJoinDate(String joinDate) {
		this.joinDate = joinDate;
	}
	public void setModDate(String modDate) {
		this.modDate = modDate;
	}
	public void setPfnum(String pfNum) {
		this.pfNum = pfNum;
	}
	public void setPftitle(String pfTitle) {
		this.pfTitle = pfTitle;
	}

	public String getpfStateNum() {
		return pfStateNum;
	}
	public void setpfNum(String pfNum) {
		this.pfNum = pfNum;
	}
	public void setpfTitle(String pfTitle) {
		this.pfTitle = pfTitle;
	}
	public void setpfStateNum(String pfStateNum) {
		this.pfStateNum = pfStateNum;
	}
	
	
	
	
}
