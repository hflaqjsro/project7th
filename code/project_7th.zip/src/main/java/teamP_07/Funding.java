package teamP_07;

/*
 * FDNUM   |CRENUM  
 * |FDTHEMENUM|FDPROJECTNM       
 * |FDTARGETPRICE|FDIMG                
 * |FDCATEGORYNUM|FDREGIDT           
 * |FDEXPDT            |FDTAGS           
 * |FDSTORYIMG           |FDSTORYSUM           
 *  |FDSTORY
 *  FDrefund, fdpolicy, statusnum, fdingprice
 */
public class Funding {
	private String creName;
	private String status_name;
	private String theme_name;
	private String category_name;
	
	private String fdNum;
	private String creNum;
	private int theme;
	private String fdtitle;
	private String fdImg;
	private int price_target;
	private int category;
	private String reg_date;
	private String expire_date;
	private String tags;
	private String storyImg;
	private String storySum;
	private String story;
	private String refund;
	private String policy;
	private int status;
	private int price;


	
	public Funding() {
		super();
	}



	public String getCreName() {
		return creName;
	}



	public String getStatus_name() {
		return status_name;
	}



	public String getTheme_name() {
		return theme_name;
	}



	public String getCategory_name() {
		return category_name;
	}



	public String getFdNum() {
		return fdNum;
	}



	public String getCreNum() {
		return creNum;
	}



	public int getTheme() {
		return theme;
	}



	public String getFdtitle() {
		return fdtitle;
	}



	public String getFdImg() {
		return fdImg;
	}



	public int getPrice_target() {
		return price_target;
	}



	public int getCategory() {
		return category;
	}



	public String getReg_date() {
		return reg_date;
	}


	public String getTags() {
		return tags;
	}



	public String getStoryImg() {
		return storyImg;
	}



	public String getStorySum() {
		return storySum;
	}



	public String getStory() {
		return story;
	}



	public String getRefund() {
		return refund;
	}



	public String getPolicy() {
		return policy;
	}



	public int getStatus() {
		return status;
	}



	public int getPrice() {
		return price;
	}

	

	public String getExpire_date() {
		return expire_date;
	}



	public void setExpire_date(String expire_date) {
		this.expire_date = expire_date;
	}



	public void setCreName(String creName) {
		this.creName = creName;
	}



	public void setStatus_name(String status_name) {
		this.status_name = status_name;
	}



	public void setTheme_name(String theme_name) {
		this.theme_name = theme_name;
	}



	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}



	public void setFdNum(String fdNum) {
		this.fdNum = fdNum;
	}



	public void setCreNum(String creNum) {
		this.creNum = creNum;
	}



	public void setTheme(int theme) {
		this.theme = theme;
	}



	public void setFdtitle(String fdtitle) {
		this.fdtitle = fdtitle;
	}



	public void setFdImg(String fdImg) {
		this.fdImg = fdImg;
	}



	public void setPrice_target(int price_target) {
		this.price_target = price_target;
	}



	public void setCategory(int category) {
		this.category = category;
	}



	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}


	public void setTags(String tags) {
		this.tags = tags;
	}



	public void setStoryImg(String storyImg) {
		this.storyImg = storyImg;
	}



	public void setStorySum(String storySum) {
		this.storySum = storySum;
	}



	public void setStory(String story) {
		this.story = story;
	}



	public void setRefund(String refund) {
		this.refund = refund;
	}



	public void setPolicy(String policy) {
		this.policy = policy;
	}



	public void setStatus(int status) {
		this.status = status;
	}



	public void setPrice(int price) {
		this.price = price;
	}



	
	

	
	
	
}
