package Creator;

public class Creator {
	private String creNum;
	private String memNum;
	private String creProfile;
	private String creNM;
	private String creDetail;
	private String crePage;
	
	
	
	
	public Creator(String creNM, String creProfile) {
		super();
		this.creNM = creNM;
		this.creProfile = creProfile;
	}
	
	public String getCreNum() {
		return creNum;
	}
	public void setCreNum(String creNum) {
		this.creNum = creNum;
	}
	public String getMemNum() {
		return memNum;
	}
	public void setMemNum(String memNum) {
		this.memNum = memNum;
	}
	public String getCreProfile() {
		return creProfile;
	}
	public void setCreProfile(String creProfile) {
		this.creProfile = creProfile;
	}
	public String getCreNM() {
		return creNM;
	}
	public void setCreNM(String creNM) {
		this.creNM = creNM;
	}
	public String getCreDetail() {
		return creDetail;
	}
	public void setCreDetail(String creDetail) {
		this.creDetail = creDetail;
	}
	public String getCrePage() {
		return crePage;
	}
	public void setCrePage(String crePage) {
		this.crePage = crePage;
	}
	
	
	
	
	
}
